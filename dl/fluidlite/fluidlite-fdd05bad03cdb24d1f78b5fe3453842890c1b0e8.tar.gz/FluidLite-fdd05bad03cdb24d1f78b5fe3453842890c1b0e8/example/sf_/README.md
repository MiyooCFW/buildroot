# Sample Sound Fonts

- __Boomwhacker.sf2__

  Fetched from [musical-artifacts.com](https://musical-artifacts.com/artifacts/922)
  Licensed under [CC-BY-3.0](https://creativecommons.org/licenses/by/3.0/legalcode)

- __Boomwhacker.sf3__

  Converted version of _Boomwhacker.sf2_
